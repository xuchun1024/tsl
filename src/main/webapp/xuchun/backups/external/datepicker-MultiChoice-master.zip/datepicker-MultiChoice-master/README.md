datepicker-MultiChoice
======================

基于JQuery UI datepicker 实现的日期多选控件