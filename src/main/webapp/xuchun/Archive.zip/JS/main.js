"use strict";

  setInterval("load()", 1000);

  function load()
  {
	  var date1 = new Date();
	  var min = date1.getMinutes();
	  var sec = date1.getSeconds();
	  var hh, mm, ss;
	  if (sec == 0)
	  {
		  if (min == 0)
		  {
			  hh = 24 - date1.getHours();
			  mm = 0;
			  ss = 0;
		  }
		  else
		  {
			  hh = 23 - date1.getHours();
			  mm = 60 - date1.getMinutes();
			  ss = 0;
		  }
	  }
	  else
	  {
		  if (min == 0)
		  {
			  hh = 23 - date1.getHours();
			  mm = 59;
			  ss = 60 - sec;
		  }
		  else
		  {
			  hh = 23 - date1.getHours();
			  mm = 59 - date1.getMinutes();
			  ss = 60 - sec;
		  }
	  }

	  document.getElementById("hh").innerHTML = printf("%02d",hh);
	  document.getElementById("mm").innerHTML = printf("%02d",mm);;
	  document.getElementById("ss").innerHTML = printf("%02d",ss);;
}

function printf(){
     var as=[].slice.call(arguments),fmt=as.shift(),i=0;
  return     fmt.replace(/%(\w)?(\d)?([dfsx])/ig,function(_,a,b,c){
          var s=b?new Array(b-0+1).join(a||''):'';
          if(c=='d') s+=parseInt(as[i++]);
          return b?s.slice(b*-1):s;
     })
}


//----------------------JSON 运作-------------------------------------------------------------------
var JSONObject= {
"name":"Bill Gates",
"age":56,
"phone":"555 1234567"};

var fts = {
  "forumTitle" : [
	{ "Title" : "马路上吃肉" , "Holder" : "逯遥", "Deadline" : "2014-08-11", "status" : 0},
	{ "Title" : "吃管氏烤翅" , "Holder" : "徐诚", "Deadline" : "2014-09-12", "status" : 1 },
	{ "Title" : "吃DQ" , "Holder" : "张三", "Deadline" : "2014-08-13", "status" : 2 }
  ]
}


/*
function setInfo()
{
	document.getElementById("login").style.display = "none";
	document.getElementById("logout").style.display = "block";
	document.getElementById("in").innerHTML = "欢迎" + JSONObject.name;
	document.getElementById("reg").innerHTML = "<a href src=''>注销<\/a>";
//	document.getElementsByTagName("reg")[0].setAttribute("a","button");

	var textile = '<div>%s需要在%s之前完成%s</div>';
	var forumTree = document.creatElement("ul");

	for (var f in forumTitles.forumTitle)
	{
		var ff = forumTitles.forumTitle[f];
		var task = document.creatElement("li");
		switch (ff.status)
		{
			case 0: //进行中
				var 
				document.getElementById("plazaSay").innerHTML = ("<div>" + forumTitles.forumTitle[f].Holder + "需要在" + forumTitles.forumTitle[f].Deadline + "之前完成" + forumTitles.forumTitle[f].Title) + document.getElementById("plazaSay").innerHTML;
				break;
			case 1://已完成
				document.getElementById("plazaSay").innerHTML = ("<div>" + forumTitles.forumTitle[f].Holder + "已经" + forumTitles.forumTitle[f].Deadline + "之前完成" + forumTitles.forumTitle[f].Title) + document.getElementById("plazaSay").innerHTML;
				break;
			case 2: //已失败
				document.getElementById("plazaSay").innerHTML = ("<div>" + forumTitles.forumTitle[f].Holder + "放弃啦" + forumTitles.forumTitle[f].Deadline + "之前完成" + forumTitles.forumTitle[f].Title) + document.getElementById("plazaSay").innerHTML;
				break;
			default:
				document.getElementById("plazaSay").innerHTML = ("<div>" + forumTitles.forumTitle[f].Holder + "需要在" + forumTitles.forumTitle[f].Deadline + "之前完成" + forumTitles.forumTitle[f].Title) + document.getElementById("plazaSay").innerHTML;
		}
		

	}
}
*/
function tagClick(tag)
{
	document.getElementById("textfield").value = document.getElementById("textfield").value + tag;
	document.getElementById("textfield").focus();
}

function enableForum(forumTitles)
{
	var textile = '<div>%s需要在%s之前完成%s</div>';
	var forumTree = document.createElement("ul");

	for (var f in forumTitles.forumTitle)
	{
		var ff = forumTitles.forumTitle[f];
		var taskLi = document.createElement("li");
		switch (ff.status)
		{
			case 0: //进行中
				taskLi.innerHTML = ff.Holder + "需要在" + ff.Deadline + "之前完成" + ff.Title;	
				break;
			case 1://已完成
				taskLi.innerHTML = ff.Holder + "已经完成" + ff.Title;
				break;
			case 2: //已失败
				taskLi.innerHTML = ff.Holder + "已经像个拖延猪一样地失败了"
				break;
			default:
				;
		}
		forumTree.appendChild(taskLi);

	}
	document.getElementById("plazaSay").appendChild(forumTree);
}


$(document).ready(function(){
	$("#in").click(function()//点击登入显示变化
	{
		$("#login").hide();
		$("#logout").show();
		$("#welcome").text(JSONObject.name);
		enableForum(fts);
	});

});

function postData(){
    var requestStr = {  
            reqStr:  'test parameter'  
    };  
    var request = {   
            requestId: 'asdfasdfa',  
            sessionId: 'asdfasdfasdf',  
            userName: 'Jeremy',  
            password:'123',  
            request: requestStr  
    };  
    //调用了jquery.json 库  
    var encoded = "{ id: 1, name: \"拉风少年\", email: null, mobile: null, password: \"123456\", addTime: 1408174347799, status: null }"//$.toJSON( request );  
    var jsonStr = encoded;  
    var actionStr = $("#actionPath").val();  
    $.ajax({  
        url : "http://211.155.86.32:8081/tosla/user/save",  
        type : 'POST',  
        data : jsonStr,  
        dataType : 'json',  
        //contentType : 'application/json',  
        success : function(data, status, xhr) {  
//         Do Anything After get Return data  
//          $.each(data.payload, function(index){  
//              $("#result").append("</br>" + data.payload[index].beanStr);  
//          });  
        },  
        Error : function(xhr, error, exception) {  
            // handle the error.    
            alert(exception.toString());  
        }  
    });  
}  


function saveUser()
{
	var url='http://211.155.86.32:8081/tosla/user/save';
    $.ajax(
		{
		url : url,
		type : "POST", 
		dataType:"json",
		contentType:'application/json;charset=UTF-8',
		data:JSON.stringify({id:'1',name:'咩哈哈',password:'test',lastIp:'',lastVisit:'1986-05-27'}),
		success : function(data) {
			alert(data.name);   
			},
		error:function(e){
			alert("err");   
			} 
		});
}